$(document).ready(function () {
    $('.slider').bxSlider({
        captions: true, 
        nextText: '',
        prevText: '',
        easing: 'jswing',});
});
